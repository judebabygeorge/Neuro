#define SW_MAJOR 0
#define SW_MINOR 3

#define SW_STRING "0.03"
