
#ifndef _ROBOTCOMM_H_
#define _ROBOTCOMM_H_

void RobotComm_Setup();
void  RobotComm_Trigger(int state_M1,int state_M2);
unsigned int RobotComm_Sensor();
#endif // _ROBOTCOMM_H
