
#ifndef _TIMER_H
#define _TIMER_H

void timer_tic();
Uint32 timer_toc();
void timer_setup();

#endif
